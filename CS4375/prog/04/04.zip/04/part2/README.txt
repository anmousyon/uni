to run:
python bayes.py train.dat test.dat

results are printed per line