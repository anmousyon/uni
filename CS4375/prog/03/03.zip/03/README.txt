to run:
	python test.py datafile

results table:
	in results.txt

datafiles used:
	haberman.data
	wine.data
	SPECT.data
	SPECTF.data
	transfusion.data

